import React, { useState } from 'react';
import LoginScreen from './screens/LoginScreen';
import MainMenuScreen from './screens/MainMenuScreen';
import ChatScreen from './screens/ChatScreen';

function App() {
  const [currentScreen, setCurrentScreen] = useState<'login' | 'menu' | 'chat'>('login');
  const [user, setUser] = useState<{ email: string; name: string } | null>(null);

  const handleLogin = (email: string, password: string) => {
    // This is a demo, so we'll just simulate a successful login
    // In a real app, you would validate credentials with your backend
    setUser({
      email,
      name: email.split('@')[0], // Use part of email as name for demo
    });
    setCurrentScreen('menu');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentScreen('login');
  };

  const handleOpenMenu = () => {
    // This would typically open a side menu
    // For the demo, we'll just log out
    if (confirm('Do you want to log out?')) {
      handleLogout();
    }
  };

  return (
    <>
      {currentScreen === 'login' && (
        <LoginScreen 
          onLogin={handleLogin}
          onSwitchToRegister={() => alert('Registration feature would be implemented here')}
        />
      )}
      
      {currentScreen === 'menu' && (
        <MainMenuScreen 
          userName={user?.name}
          onStartChat={() => setCurrentScreen('chat')}
          onOpenMenu={handleOpenMenu}
        />
      )}
      
      {currentScreen === 'chat' && (
        <ChatScreen 
          onBack={() => setCurrentScreen('menu')}
          onOpenMenu={handleOpenMenu}
        />
      )}
    </>
  );
}

export default App;