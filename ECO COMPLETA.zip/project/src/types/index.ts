export interface User {
  id: string;
  email: string;
  name?: string;
}

export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'echo';
  timestamp: Date;
}

export interface Conversation {
  id: string;
  messages: Message[];
  title?: string;
  createdAt: Date;
}