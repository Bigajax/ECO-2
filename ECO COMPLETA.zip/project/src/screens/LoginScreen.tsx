import React, { useState } from 'react';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import AppLayout from '../components/AppLayout';
import { RadiationIcon as InformationIcon } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (email: string, password: string) => void;
  onSwitchToRegister: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onSwitchToRegister }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Por favor, insira seu email e senha');
      return;
    }
    setError('');
    onLogin(email, password);
  };

  return (
    <AppLayout>
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-soft p-6 sm:p-8 animate-slide-up">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-serenity/10 mb-4">
            <InformationIcon className="h-8 w-8 text-serenity" />
          </div>
          <h1 className="text-2xl font-semibold text-neutral-800">Bem-vindo ao ECO</h1>
          <p className="text-neutral-500 mt-1">Entre para continuar sua jornada</p>
        </div>

        <form onSubmit={handleSubmit}>
          <Input
            label="Email"
            type="email"
            placeholder="seuemail@exemplo.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />
          <Input
            label="Senha"
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
          />

          {error && (
            <div className="mb-4 p-3 rounded bg-red-50 text-red-600 text-sm">
              {error}
            </div>
          )}

          <div className="mt-6">
            <Button type="submit" variant="primary" fullWidth>
              Entrar
            </Button>
          </div>
          
          <div className="mt-4">
            <Button type="button" variant="text" fullWidth onClick={onSwitchToRegister}>
              Criar nova conta
            </Button>
          </div>
          
          <div className="text-center mt-4">
            <button type="button" className="text-sm text-serenity hover:underline">
              Esqueceu sua senha?
            </button>
          </div>
        </form>
        
        <div className="mt-8 pt-4 border-t border-neutral-200">
          <Button 
            variant="outline" 
            fullWidth
            type="button"
            className="flex items-center justify-center gap-2 text-sm"
          >
            <span className="animate-pulse-subtle">✨</span>
            Iniciar tour pelo ECO
          </Button>
        </div>
        
        <div className="mt-6 text-center text-xs text-neutral-500 flex justify-center space-x-3">
          <a href="#" className="hover:text-serenity transition-colors">Termos de Uso</a>
          <span>•</span>
          <a href="#" className="hover:text-serenity transition-colors">Política de Privacidade</a>
        </div>
      </div>
    </AppLayout>
  );
};

export default LoginScreen;