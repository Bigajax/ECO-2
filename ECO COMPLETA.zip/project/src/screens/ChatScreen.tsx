import React, { useState, useRef, useEffect } from 'react';
import { Button } from '../components/Button';
import { ArrowLeft, Send, Menu } from 'lucide-react';
import { Message } from '../types';

interface ChatScreenProps {
  onBack: () => void;
  onOpenMenu: () => void;
}

const ChatScreen: React.FC<ChatScreenProps> = ({ onBack, onOpenMenu }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Olá! Eu sou o ECO. Como posso ajudar você hoje?',
      sender: 'echo',
      timestamp: new Date(),
    },
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleSend = () => {
    if (!input.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: 'user',
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    // Simulate Echo response after a short delay
    setTimeout(() => {
      const echoMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: `Recebi sua mensagem: "${input}". Como demonstração, esta é uma resposta simulada do ECO.`,
        sender: 'echo',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, echoMessage]);
    }, 1000);
  };

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-soft px-4 py-3 flex items-center sticky top-0 z-10">
        <button 
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-neutral-600 hover:bg-neutral-100 transition-colors mr-2"
        >
          <ArrowLeft size={20} />
        </button>
        
        <div className="flex-1">
          <h1 className="text-lg font-medium text-neutral-800">ECO</h1>
          <p className="text-xs text-neutral-500">Seu assistente de IA</p>
        </div>
        
        <button 
          onClick={onOpenMenu}
          className="w-10 h-10 rounded-full flex items-center justify-center text-neutral-600 hover:bg-neutral-100 transition-colors"
        >
          <Menu size={20} />
        </button>
      </header>
      
      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="max-w-2xl mx-auto space-y-4 pb-16">
          {messages.map((message) => (
            <div 
              key={message.id}
              className={`
                flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}
                animate-slide-up
              `}
            >
              <div 
                className={`
                  max-w-[85%] rounded-2xl p-3 sm:p-4
                  ${
                    message.sender === 'user'
                      ? 'bg-serenity text-white rounded-tr-none'
                      : 'bg-white border border-neutral-200 shadow-soft rounded-tl-none'
                  }
                `}
              >
                {message.content}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      {/* Input area */}
      <div className="sticky bottom-0 bg-white border-t border-neutral-200 p-3">
        <div className="max-w-2xl mx-auto flex items-center gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Escreva para o ECO..."
              className="w-full rounded-full py-3 px-4 pr-12 border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-serenity focus:border-transparent"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className={`
                absolute right-1 top-1/2 -translate-y-1/2
                h-9 w-9 rounded-full flex items-center justify-center
                ${
                  input.trim()
                    ? 'bg-serenity text-white'
                    : 'bg-neutral-200 text-neutral-400'
                }
                transition-colors
              `}
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
      
      {/* ECO Avatar */}
      <div className="fixed bottom-20 right-4 sm:bottom-24 sm:right-8 z-10 animate-pulse-subtle">
        <div className="w-12 h-12 rounded-full bg-rose-quartz shadow-medium flex items-center justify-center">
          <span className="text-white font-medium">E</span>
        </div>
      </div>
    </div>
  );
};

export default ChatScreen;