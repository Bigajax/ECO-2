import React from 'react';
import { Button } from '../components/Button';
import AppLayout from '../components/AppLayout';
import { Menu, MessageCircle, User } from 'lucide-react';

interface MainMenuScreenProps {
  onStartChat: () => void;
  onOpenMenu: () => void;
  userName?: string;
}

const MainMenuScreen: React.FC<MainMenuScreenProps> = ({ 
  onStartChat, 
  onOpenMenu,
  userName = 'Usuário' 
}) => {
  return (
    <AppLayout>
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-soft h-[500px] flex flex-col relative animate-fade-in">
        <header className="p-4 flex items-center justify-between">
          <button 
            onClick={onOpenMenu}
            className="w-10 h-10 rounded-full flex items-center justify-center text-neutral-600 hover:bg-neutral-100 transition-colors"
          >
            <Menu size={20} />
          </button>
          
          <div className="w-10 h-10 rounded-full bg-rose-quartz flex items-center justify-center">
            <User size={16} className="text-white" />
          </div>
        </header>
        
        <div className="flex-1 flex flex-col items-center justify-center p-8 -mt-8">
          <h1 className="text-2xl font-semibold text-neutral-800 mb-2">
            Menu ECO
          </h1>
          <p className="text-neutral-500 text-center mb-12 max-w-xs">
            Bem-vindo de volta, {userName}. O ECO está pronto para ajudar.
          </p>
          
          <div className="w-full max-w-xs">
            <Button 
              variant="primary"
              size="lg"
              fullWidth
              onClick={onStartChat}
              className="flex items-center justify-center gap-2 shadow-soft"
            >
              <MessageCircle size={20} />
              <span>Conversar com ECO</span>
            </Button>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-serenity-light/20 to-transparent rounded-b-2xl pointer-events-none" />
        </div>
      </div>
    </AppLayout>
  );
};

export default MainMenuScreen;