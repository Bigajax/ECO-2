import React from 'react';

interface AppLayoutProps {
  children: React.ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-quartz-light via-neutral-50 to-serenity-light p-4 sm:p-6 flex flex-col items-center justify-center">
      <div className="w-full max-w-md animate-fade-in">
        {children}
      </div>
    </div>
  );
};

export default AppLayout;